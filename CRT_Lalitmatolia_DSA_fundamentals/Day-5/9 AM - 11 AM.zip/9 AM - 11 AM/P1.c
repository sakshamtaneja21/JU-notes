#include<stdio.h>
int main()
{
	char a='1';
	switch(a)
	{
		case 1:
			printf("JECRC\n");
		case 2:
			printf("JU\n");
		case 3:
			printf("CSE\n");
		default:
			printf("Invalid\n");
	}
}

/*
65 - 90 => A - Z
97 - 122 => a - z
48 - 57 => 0 - 9
*/
