#include<stdio.h>
int main()
{
	int a=1;
	switch(a)
	{
		case 1:
			printf("JECRC\n");
			break;
		case 2:
			printf("JU\n");
			break;
		case 3:
			printf("CSE\n");
			break;
		default:
			printf("ECE\n");
			break;
	}
}

/*
65 - 90 => A - Z
97 - 122 => a - z
48 - 57 => 0 - 9
*/
