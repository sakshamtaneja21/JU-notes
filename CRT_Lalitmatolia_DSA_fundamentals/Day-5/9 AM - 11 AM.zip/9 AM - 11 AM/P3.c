#include<stdio.h>
int main()
{
	int a=1;
	switch(a)
	{
		case 1:
			printf("JECRC\n");
		case 2:
			printf("JU\n");
			break;
		default:
			printf("ECE\n");
		case 3:
			printf("CSE\n");
		
	}
}

