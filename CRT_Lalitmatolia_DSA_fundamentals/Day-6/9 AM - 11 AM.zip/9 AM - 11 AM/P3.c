#include<stdio.h>
int main()
{
	char c ='A';
	printf("%d\n",sizeof(c));
	printf("%d\n",sizeof(char));
	printf("%d\n",sizeof('3'));
}
