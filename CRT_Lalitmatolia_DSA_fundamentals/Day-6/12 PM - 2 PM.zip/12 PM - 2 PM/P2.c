#include<stdio.h>
class A
{
	
};
int main()
{
	A obj;
	printf("%d\n", sizeof(obj));
}
