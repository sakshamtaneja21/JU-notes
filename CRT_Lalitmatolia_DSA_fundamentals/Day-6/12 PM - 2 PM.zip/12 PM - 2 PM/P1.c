#include<iostream>
using namespace std;

int main()
{
	float a = 3.500000;
	cout<<setprecision(2);
	cout<<a<<endl;
	return 0;
}
