#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	float a = 3.555000;
	cout<<setprecision(4)<<a<<endl;
	return 0;
}
