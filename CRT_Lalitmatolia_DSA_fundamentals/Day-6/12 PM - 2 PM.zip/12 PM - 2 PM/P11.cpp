#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	double x = 11.666666;
	cout<<round(x)<<endl;
	return 0;
}
