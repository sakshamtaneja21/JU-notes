#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	float a = 5.555555;
	cout<<setprecision(4)<<a;
}
