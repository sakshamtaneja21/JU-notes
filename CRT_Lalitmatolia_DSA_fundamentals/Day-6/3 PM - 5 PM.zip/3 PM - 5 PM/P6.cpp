#include<iostream>
using namespace std;
int main()
{
	int a = 10, b = 20, c;
	c = a > b ? a : b;  // c = 10 > 20 ? 10 : 20;
	cout<<"C="<<c<<endl;
	return 0;
}

// WAP to find the maximum of three numbers using conditional operator.

