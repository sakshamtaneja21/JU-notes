#include<iostream>
using namespace std;
int main()
{
	int i = 10;
	do
	{
		cout<<i<<endl;
		i++;
	}while(10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0);
	return 0;
}
