#include<iostream>
using namespace std;
int func(void);
int main()
{
	func();
}
int func()
{
	printf("Hello");
}
