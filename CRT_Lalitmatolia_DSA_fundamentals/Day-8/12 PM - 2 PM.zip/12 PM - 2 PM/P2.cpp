#include<iostream>
using namespace std;
class Test
{
    public:
    Test()
    {
        cout<<"Lalit";
    }
    ~Test()
    {
        cout<<" Matoliya";
    }
};
int main()
{
    Test ob;
    return 0; 
}
