#include<stdio.h>
#define int double
main()
{
	printf("%d",sizeof(int));
	
}
