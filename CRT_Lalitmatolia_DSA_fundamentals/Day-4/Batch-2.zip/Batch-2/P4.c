#include<stdio.h>
int main()
{
	int a = 1;
	switch(a)
	{
		default:
			printf("Hii");
		case 1:
			printf("Hello");
		case 2:
			printf("Hi");
		case 3:
			printf("Go");
	}
	return 0;
}
