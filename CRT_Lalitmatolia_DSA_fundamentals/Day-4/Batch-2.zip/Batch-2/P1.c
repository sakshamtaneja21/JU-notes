#include<stdio.h>
int main()
{
	char str[]="Fascimile";
	printf("%s", str+5);
	return 0;
}
