#include<stdio.h>
int main()
{
	printf("\0");
	printf("%u",*"\0");
	return 0;
}

