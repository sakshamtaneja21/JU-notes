#include<stdio.h>
int main()
{
	char s[]="Hello";
	printf("%s\n", s);
	printf("%s\n", s);
	printf("%d\n", *s);
	return 0;
}

/*

%s = For Representating the string
%d = For reprenting the integer
%ld = For Long Int
%u = For unsigned int
%c = For character
%x or %X = For Hexadecimal
%o = For Octal
%f = Floating
%lf = Double
%Lf = Long Double

*/
