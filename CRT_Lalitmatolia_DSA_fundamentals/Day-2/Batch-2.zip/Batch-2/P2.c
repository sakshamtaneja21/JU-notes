#include<stdio.h>
int main()
{
	int x = 49;
	while(x--);
	printf("%d\n", x); // -1
}
