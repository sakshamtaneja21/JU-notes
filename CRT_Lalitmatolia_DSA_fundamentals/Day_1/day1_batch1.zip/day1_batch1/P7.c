#include<stdio.h>
int main()
{
	int x = 1;
	do
	{
		printf("%d\n", x);
		x++;
	}while(x<=10);
	return 0;
}
/*
initialization;
do
{
	//statement
	incrment/decrement
}while(condition);
*/
