#include<stdio.h>
#include "M.h"

int main()
{
	func();
}
