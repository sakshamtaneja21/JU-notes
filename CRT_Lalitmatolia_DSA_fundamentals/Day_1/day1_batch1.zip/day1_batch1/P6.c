#include<stdio.h>
int main()
{
	int x = 10;
	while(x>=1)
	{
		printf("%d\n", x);
		x = x - 1;
	}
	return 0;
}

/*
initialization;
while(condition)
{
	statement;
	increment/decrement;
}

*/
