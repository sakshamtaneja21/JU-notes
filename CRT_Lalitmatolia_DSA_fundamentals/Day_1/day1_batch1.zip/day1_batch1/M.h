void func()
{
	printf("Hello");
}
