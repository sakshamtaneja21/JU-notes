#include<stdio.h>
int main()
{
	int x = 10;
	while(x < 10)
	{
		printf("hello");
		x++;
	}
	
	do
	{
		printf("Hello");
		x++;
	}while(x < 10);
	return 0;
}
