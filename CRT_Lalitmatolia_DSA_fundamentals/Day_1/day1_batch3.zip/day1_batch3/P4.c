#include<stdio.h>
int main()
{
	char a = 'Z';
	printf("%d = %c", a, a);
	return 0;
}
