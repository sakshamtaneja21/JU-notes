#include<stdio.h>
int main()
{
	int x=017, y=0xA2, z=0X2C;
    printf("X=%d Y=%d Z=%d", x, y, z);
	return 0;
}

