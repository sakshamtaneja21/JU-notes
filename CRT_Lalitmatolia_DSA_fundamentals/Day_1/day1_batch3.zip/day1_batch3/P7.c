#include<stdio.h>
int main()
{
	static int x=90;
	printf("X=%d", x);
	return 0;
}
