#include<iostream>
using namespace std;
int main()
{
	int x = 013, y=0x1A, z=0X3C;
	cout<<"X="<<x<<" Y="<<y<<" Z="<<z;
	return 0;
}
