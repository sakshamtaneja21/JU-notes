#include<stdio.h>
int main()
{
	int a = 57;
	printf("%d = %c", a, a);
	return 0;
}

/*
ASCII (American Standard Code for Information Interchange)
65 - 90 ==> A - Z
97 - 122 ==> a - z
48 - 57 ==> 0 - 9
*/
