#include<stdio.h>
int main()
{
	int x=0x1A, y=0X1A, z=017;
	printf("%x %X %o\n", x, y, z);
	printf("%d %d %d", x, y, z);
	return 0;
}
