#include<stdio.h>
int main()
{
	int x=1;
	do
	{
		printf("%d\t", x);
		x++;
	}while(x<=10);
	return 0;
}

/*


*/
