#include<stdio.h>
int main()
{
	int x = 10;
	while(x>=1)
	{
		printf("%d\n", x);
		x--;
	}
	return 0;
}

/*
syntax for the while loop: Entry Controlled Loop
initialization;
while(condition)
{
	statement;
	increment/decrement;
}
*/
