#include<stdio.h>
int main()
{
	int x=100, y;
	printf("%d %d %d", ++x, x++, x);
	
	return 0;
}
