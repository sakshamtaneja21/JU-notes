#include<stdio.h>
int main()
{	
	static int x;
	printf("%d", x);
	return 0;
}
