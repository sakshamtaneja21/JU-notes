#include<stdio.h>
int main()
{
	int a;
	printf("%d\n",sizeof(a));
	printf("%d\n", sizeof(int));
	return 0;
}
