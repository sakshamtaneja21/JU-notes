#include<stdio.h>
int main()
{
	int a = -1;
	printf("%d\n", a);
	printf("%u\n", a);
	return 0;
}
