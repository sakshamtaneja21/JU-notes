#include<stdio.h>
int main()
{
	int x;
	for(x=1; x<=10; x++)
	{
		printf("%d\t", x); // 1    2    3   ...... 10
	}
	printf("\n%d", x);
	return 0;
}
/*
for(initialization; condition; increment/decrement)
{
	//statement;
}
*/
