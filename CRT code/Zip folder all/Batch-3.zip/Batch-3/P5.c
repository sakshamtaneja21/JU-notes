#include<stdio.h>
int main()
{
	for(;;)
		printf("Hello");
	return 0;
}
