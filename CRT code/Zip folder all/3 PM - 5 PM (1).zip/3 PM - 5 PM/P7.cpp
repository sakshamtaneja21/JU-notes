#include<iostream>
using namespace std;
int main()
{
	char *string[5];
	cout<<sizeof(string)<<endl;
	return 0;
}
