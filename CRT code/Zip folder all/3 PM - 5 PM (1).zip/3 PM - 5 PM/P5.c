#include<stdio.h>
int main()
{
	char str[10]="Angel";
	str[5]='d';
	printf("%s",str);
	return 0;
}
