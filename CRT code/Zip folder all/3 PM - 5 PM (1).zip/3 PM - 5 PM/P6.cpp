#include<iostream>
#include<string.h>
using namespace std;
int main()
{
	char str[10]="Angel";
	str[5]='d';
	cout<<str<<endl;
	cout<<strlen(str)<<endl;
	return 0;
}
