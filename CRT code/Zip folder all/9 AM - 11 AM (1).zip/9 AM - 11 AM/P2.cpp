#include<iostream>
int main()
{
	std::cout<<"print me"; // it prints print me
	return 0;
}
