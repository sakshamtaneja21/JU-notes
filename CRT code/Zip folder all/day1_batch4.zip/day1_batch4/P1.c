#include<stdio.h>
int main()
{
	int a = 0x1F, b=0xAC, c = 014;
	printf("A=%d B=%d C=%d", a, b, c);
	return 0;
}
