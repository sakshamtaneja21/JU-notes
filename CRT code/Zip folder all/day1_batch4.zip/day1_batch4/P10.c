#include<stdio.h>
int main()
{
	int x = 1;
	do
	{
		printf("%d  ", x);
		x++;
	}while(x<=10);
	return 0;
}
/*
1 to 10
*/
/*
initialization;
do
{
	statement;
	increment/decrement;
}while(condition);
*/
