#include<stdio.h>
int  main()
{
	int a = 4, b = 3;
	float f;
	f = a / b;
	printf("%f", f);
	return 0;
}
