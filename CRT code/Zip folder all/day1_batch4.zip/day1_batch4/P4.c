#include<stdio.h>
int main()
{
	int x = 10;
	x++;
	printf("X=%d", x);
	return 0;
}
