#include<stdio.h>
int main()
{
	int a = 1;
	switch(a)
	{
		case 1:
			printf("Hello\n");
		case 2:
			printf("Hi\n");
			break;
		case 3:
			printf("Go\n");
		default:
			printf("Hii\n");
	}
}
