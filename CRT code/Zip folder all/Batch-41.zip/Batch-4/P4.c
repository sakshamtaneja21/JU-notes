#include<stdio.h>
int main()
{
	printf("%u\n", -3);
	return 0;
}
