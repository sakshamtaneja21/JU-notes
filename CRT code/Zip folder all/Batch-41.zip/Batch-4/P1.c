#include<stdio.h>
int main()
{
	char str[]="Fascimile";
	printf("%c", *(str+5));
	return 0;
}

/*
Format Specifiers
%c = to print character
%d = to print int value
%x or %X = For printing hexadecimal
%o = Octal Printing
%f = Floating printing
%lf = double 
%Lf = long double
%s = string
%g = short form of float
%e or %E = Exponential Form
*/
