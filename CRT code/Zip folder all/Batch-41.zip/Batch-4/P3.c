#include<stdio.h>
int main()
{
	char str[40]="Sales\0man";
	printf("%s", str);
	return 0;
}
